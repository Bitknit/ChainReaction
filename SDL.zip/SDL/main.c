#include "stdio.h"
#include "stdlib.h"
#include "props.h"
#include "string.h"

int main(){
    char user1[80], user2[80];
    int cell;
    int x, y;
    int gamer;
    int firstRun = FALSE;
    clear();
    setup();

    printf("Welcome to the game, press a key to continue");
    getchar();
    printf("Enter first player's name: ");
    scanf("%s", &user1);
    printf("Enter second player's name: ");
    scanf("%s", &user2);
    printf("Press a key to begin the game");
    getchar();

    while(cell != 888){
        clear();
        if(currentUser == 2) currentUser=1; else currentUser++;
        printf("\n\n\tTurn for user (%d) : %s",currentUser, currentUser==1?user1:user2);
        screen();
        printf("\n\tEnter the cell no to enter: ");
        scanf("%d", &cell);
        x = cell /10, y = cell % 10;
        if((x > maxx || y > maxy) && cell != 888){
            printf("\nInvalid Entry!");
            continue;
        }else{
            place(cell);
        }
        if(!firstRun){
            firstRun = TRUE;
        }
        else{
            if(checkGame()>0){
                gamer = checkGame();
                screen();
                printf("\tUser %s won the game!\n", gamer==1?user1:user2);
                break;
            }
        }
    }
}
