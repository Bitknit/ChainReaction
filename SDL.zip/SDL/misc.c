#include "stdlib.h"
#include "stdio.h"
#include "props.h"

char skipKeys(int);
int propagate(int);
int screen(){
    int x, y;
    clear();
    printf("\n\n\n           0        1        2        3        4\n");
    printf("______________________________________________________\n\n");
    for(x=0; x< maxx; x++){
        printf("%d \t|", x);
        for(y=0; y<maxy; y++){
            printf("%3d%-6c", user[x][y], keys[x][y]);
        }
        printf("\n\n");
    }
    printf("\n");
}
void clear(){
    system("clear");
}
int setup(){
    int i, j;
    for(i=0; i<maxx; i++){
        for(j=0; j<maxy; j++){
            keys[i][j] = '_';
            user[i][j] = 0;
        }
    }
}
int checkGame(){
    int i, j;
    int x=0, y=0;
    int userO = 0;
    for(i=0; i<maxx; i++){
        for(j=0; j<maxy; j++){
            userO = user[i][j];
            if(userO ==1){
                x++;
            }else if(userO == 2){
                y++;
            }
        }
    }
    if(x == 0 && y != 0){
        return 2;
    }
    else if(x!=0 && y == 0 ){
        return 1;
    }
    return 0;
}
int place(int cell){
    int x, y;
    char ch;
    x=cell/10;
    y=cell%10;

    ch = keys[x][y];
    if(user[x][y] == currentUser || user[x][y] == 0){
        if(ch == '_'){
            keys[x][y] = '&';
            user[x][y] = currentUser;
        }
        else if(ch == '&'){
            keys[x][y] = '@';
            user[x][y] = currentUser;
        }
        else if(ch == '@'){
            keys[x][y] = '$';
            user[x][y] = currentUser;
        }
        else{
            propagate(cell);
        }
    }
    else{
        printf("\nPlace your key in your own position! Your turn skipped..\n");
    }
}
int propagate(int cell){
    int x, y;
    char ch;

    x = cell /10;
    y = cell %10;
    ch = keys[x][y];

    keys[x][y] = '_';
    user[x][y] = 0;

    if(x+1 < maxx) {
        user[x+1][y] = currentUser;
        keys[x+1][y] = skipKeys(cell+10);
    }
    if(x > 0) {
        user[x-1][y] = currentUser;
        keys[x-1][y] = skipKeys(cell-10);
    }
    if(y+1<maxy) {
        user[x][y+1] = currentUser;
        keys[x][y+1] = skipKeys(cell+1);
    }
    if(y>0) {
        user[x][y-1] = currentUser;
        keys[x][y-1] = skipKeys(cell-1);
    }
}
char skipKeys(int cell){
    int x, y;
    char ch;
    x = cell / 10;
    y = cell % 10;
    ch = keys[x][y];
    if(ch == '_'){
        ch = '&';
    } else if(ch == '&'){
        ch = '@';
    } else if(ch == '@'){
        ch = '$';
    }
    return ch;
}
