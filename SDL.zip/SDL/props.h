#ifndef SDL_PROPS_H
#define SDL_PROPS_H

#define RESDIR "res/"
#define maxx 5
#define maxy 5
#define FALSE 0
#define TRUE 1

int     currentUser;
int     screen();
void    clear();
char    keys[maxx][maxy];
int     user[maxx][maxy];
int     setup();
int     checkGame();
int     place(int cell);
#endif